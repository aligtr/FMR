s = serial('COM1');

set(s,'BaudRate',4800);

fopen(s);

fprintf(s,'something to send')

out = fscanf(s)

fclose(s); delete(s);