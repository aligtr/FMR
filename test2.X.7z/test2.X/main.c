// CONFIG3
#pragma config WPFP = WPFP511           // Write Protection Flash Page Segment Boundary (Highest Page (same as page 170))
#pragma config WPDIS = WPDIS            // Segment Write Protection Disable bit (Segmented code protection disabled)
#pragma config WPCFG = WPCFGDIS         // Configuration Word Code Page Protection Select bit (Last page(at the top of program memory) and Flash configuration words are not protected)
#pragma config WPEND = WPENDMEM         // Segment Write Protection End Page Select bit (Write Protect from WPFP to the last page of memory)

// CONFIG2
#pragma config POSCMOD = HS             // Primary Oscillator Select (HS oscillator mode selected)
#pragma config DISUVREG = ON           // Internal USB 3.3V Regulator Disable bit (Regulator is disabled)
#pragma config IOL1WAY = ON             // IOLOCK One-Way Set Enable bit (Write RP Registers Once)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSCO functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Both Clock Switching and Fail-safe Clock Monitor are disabled)
#pragma config FNOSC = PRI           // Oscillator Select (Fast RC oscillator with Postscaler (FRCDIV))
#pragma config PLL_96MHZ = ON           // 96MHz PLL Disable (Enabled)
#pragma config PLLDIV = DIV12           // USB 96 MHz PLL Prescaler Select bits (Oscillator input divided by 12 (48MHz input))
#pragma config IESO = OFF               // Internal External Switch Over Mode (IESO mode (Two-speed start-up)disabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = ON              // Watchdog Timer Enable (Watchdog Timer is enabled)
#pragma config ICS = PGx1               // Comm Channel Select (Emulator functions are shared with PGEC1/PGED1)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = ON              // JTAG Port Enable (JTAG port is enabled)


#define FOSC 20000000
#define FCY (FOSC/2)

#include <libpic30.h>
#include <xc.h>

#include <stdio.h>
#include <stdlib.h>

//#ifndef _XTAL_FREQ 
//#define _XTAL_FREQ 10000000 // ??????????? ???????? ???????  10 ???  ??? 
//#endif 

/*
 * 
 */

int main(void) {
    int i;
 T1CONbits.TCS = 0;
 T1CONbits.TCKPS = 0b10;
 TMR1 = 0;  
 T1CONbits.TON = 1;
TRISEbits.TRISE1=0; 
TRISAbits.TRISA1=0; 
PORTAbits.RA1 = 1;

while (1){
sevr(0b100111000);
PORTEbits.RE1 = 0;
PR1=0;
__delay_ms(1000);
sevr(0b1001110000);
__delay_ms(1000);

}



return 0;
}
void sevr(int A){
 //PR1 = 0b100111000;// 1
//PR1 = 0b1001110000; //2
//PR1 = 0b100010001;//1.75
//PR1 = 0b10011100;//0.5
//PR1 = 0b11101010; //1.5
    PR1 = A;
 IFS0bits.T1IF=0;
 TMR1 = 0;
 PORTEbits.RE1 = 1;
 while(IFS0bits.T1IF==0);
//PR1 = 0b101011111101;//18
 //PR1 = 0b101110011001; //19
 //PR1 = 0b101111100111; //19.5
//PR1 = 0b101101001011;//18.5
//PR1 = 0b101100100100;//18.25
 PR1 = 0b110000110101 - A;
 IFS0bits.T1IF=0;
 TMR1 = 0;
 PORTEbits.RE1 = 0;
 while(IFS0bits.T1IF==0);
 return 0;
}