// CONFIG3
#pragma config WPFP = WPFP511           // Write Protection Flash Page Segment Boundary (Highest Page (same as page 170))
#pragma config WPDIS = WPDIS            // Segment Write Protection Disable bit (Segmented code protection disabled)
#pragma config WPCFG = WPCFGDIS         // Configuration Word Code Page Protection Select bit (Last page(at the top of program memory) and Flash configuration words are not protected)
#pragma config WPEND = WPENDMEM         // Segment Write Protection End Page Select bit (Write Protect from WPFP to the last page of memory)

// CONFIG2
#pragma config POSCMOD = HS             // Primary Oscillator Select (HS oscillator mode selected)
#pragma config DISUVREG = ON           // Internal USB 3.3V Regulator Disable bit (Regulator is disabled)
#pragma config IOL1WAY = ON             // IOLOCK One-Way Set Enable bit (Write RP Registers Once)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSCO functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Both Clock Switching and Fail-safe Clock Monitor are disabled)
#pragma config FNOSC = PRI           // Oscillator Select (Fast RC oscillator with Postscaler (FRCDIV))
#pragma config PLL_96MHZ = ON           // 96MHz PLL Disable (Enabled)
#pragma config PLLDIV = DIV12           // USB 96 MHz PLL Prescaler Select bits (Oscillator input divided by 12 (48MHz input))
#pragma config IESO = OFF               // Internal External Switch Over Mode (IESO mode (Two-speed start-up)disabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = ON              // Watchdog Timer Enable (Watchdog Timer is enabled)
#pragma config ICS = PGx1               // Comm Channel Select (Emulator functions are shared with PGEC1/PGED1)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG port is enabled)


#define FOSC 32000000
#define FCY (FOSC/2)

#include <libpic30.h>
#include <xc.h>

#include <stdio.h>
#include <stdlib.h>

#define DUTY 20000

//#ifndef _XTAL_FREQ 
//#define _XTAL_FREQ 10000000 // ??????????? ???????? ???????  10 ???  ??? 
//#endif 

/*
 * 
 */

void init_PWM1()
{
    RPOR1bits.RP2R  = 18;// pwm D8
    TMR1=0;// timer=0
    PR1 = 40000; // period signala
    T1CONbits.TCKPS=0b01;//preddel.8
    T1CONbits.TON=1; // timer on
    OC1RS=40000; //peiod signala 20ms
    //OC1R=DUTY; //?????? ????????
    OC1CON2bits.SYNCSEL= 0b01011; //sinchronizacia with timer
    OC1CON2bits.OCTRIG=0b0;//pwm configuration
    OC1CON1bits.OCTSEL=0b100;   
    OC1CON1bits.OCM=0b110;
}

void init_T2()//timer for ADC
{
    //IEC0bits.T2IE=1;
    T2CONbits.TCKPS=3;// ustanovka preddel    
    IPC1bits.T2IP=1;//prioritet preriv 1
    PR2=15625; //period scheta
    T2CONbits.TON=1; // pusk timer
}  

char outadc[1000]; // massiv dan.
int countServ, countPot; //schetchici
void __attribute__((interrupt, auto_psv))_T2Interrupt(void) //preriv. timer2
{   
    int a;
    TMR2=0;
    IFS0bits.T2IF = 0; // sbros flaga
    outadc[countPot]=10+(read_Adc()/4-10)/4.25; //zapis s ADC
    transmit_UART(outadc[countPot]); // peredacha cherez UART
    countPot++; // perehod na sled. element mass.
}


char Rword;
void __attribute__((interrupt, auto_psv))_U1RXInterrupt(void)//preriv. po priemu UART
{   
    U1STAbits.OERR = 0; //flag error
    IFS0bits.U1RXIF = 0; // sbros flaga
    if (U1STAbits.URXDA==1) { //proverka simvola v priemnike
        Rword=U1RXREG; // zapis' simvola
    }
}


void __attribute__((interrupt, auto_psv))_U1TXInterrupt(void)//preriv.po otpravke
{
    IFS0bits.U1TXIF = 0; //flag prerivania v 0
}


void init_UART()// initional UART
{
  
    RPOR7bits.RP15R  = 3;// transmit F8
    RPINR18bits.U1RXR=16;
    U1MODEbits.PDSEL=0b00; 
    U1MODEbits.BRGH=1;
    U1BRG=(FCY/4/115200)-1; // speed
    U1MODEbits.STSEL=0;
    IPC3bits.U1TXIP2 = 1; //Set Uart TX Interrupt Priority
    IPC3bits.U1TXIP1 = 0;
    IPC3bits.U1TXIP0 = 0;

    IPC2bits.U1RXIP2 = 1; //Set Uart RX Interrupt Priority
    IPC2bits.U1RXIP1 = 0;
    IPC2bits.U1RXIP0 = 0; //

    IFS0bits.U1TXIF = 0;// sbros flaga
    IEC0bits.U1TXIE = 1; //Enable Transmit Interrupt
    IFS0bits.U1RXIF = 0;
    IEC0bits.U1RXIE = 1; //Enable Receive Interruptreturn;

    U1MODEbits.UARTEN=1;// uart on
    U1STAbits.URXISEL=0; 
    U1STAbits.UTXISEL0=1;
 }

void transmit_UART(char Tword)//transmit 8bits
{ 
    U1STAbits.UTXEN=1; // transmit on
    U1TXREG=Tword;   // transmiting word
}


int read_Adc ()// Read of ADC
{
	AD1CHS = 1;						// podkluchenie 1 analog. exit (adc))
	AD1CON1bits.SAMP = 1;			// ADC ON
		while (!AD1CON1bits.DONE);	// while adc work - nothing
	AD1CON1bits.SAMP = 0;			//  adc OFF
	return ADC1BUF0;				// retutn znachenia c ADC
}
void Adc_init()
{		  
	AD1PCFG = 0b1111111111111101;	//podkluchenie 1 analog. exit (mux)
	AD1CON1 = 0x00E0;				
	AD1CON2 = 0;
	AD1CON3 = 0x1F3F;				
	AD1CSSL = 2;					

	AD1CON1bits.ADON = 1;
}


void __attribute__((interrupt, auto_psv))_INT1Interrupt(void)// knopka
{
    __delay_ms(1);
    if (!LATEbits.LATE1){ //if svet off
        countPot=0; //sbros
        countServ=0;//sbros
        free(outadc); //clear
    }
    LATEbits.LATE1=!LATEbits.LATE1;//invertiruem svet
    IEC0bits.T2IE=!IEC0bits.T2IE; //invertiruem preriv.timer2
    IFS1bits.INT1IF=0;// sbros flaga preriv. knopki
    //IEC0bits.T2IE=0;
}

void init_inter1(){ // podkl.preriv. knopki
    TRISCbits.TRISC1=1; // c1 vvod
    RPINR0bits.INT1R=38;//c1 otdaet int-0
    IEC1bits.INT1IE=1; //razresh. preriv
    IPC5bits.INT1IP=1; // prioritet
}

int main(void) {
    char Tword;
    int i=0;
    init_inter1();
    init_PWM1();
    init_T2();
    __delay_ms(20);
    init_UART();
    __delay_ms(20);
    Adc_init();
    __delay_ms(20);
    TRISEbits.TRISE1=0;
    //LATEbits.LATE1=1;
while (1){
    if (!LATEbits.LATE1){
    for(countServ=0; countServ<countPot;countServ++){
        transmit_UART(outadc[countServ]);
        OC1R=100*outadc[countServ];
    __delay_ms(100);
    }
    __delay_ms(3000);
    }
    }
    return 0;
}

void dvig(){
    int i;
    for(i=0;i<10;i++){
    OC1R=1000+400*i;//0.5-min - 0
    __delay_ms(100);
    }
        for(i=10;i>0;i--){
    OC1R=1000+400*i;//0.5-min - 0
    __delay_ms(100);
    }
    
    
    
     /*countPot=0;
    countServ=0;
    free(outadc);
        for(i=0;i<10;i++){
        countPot++;
        outadc[countPot-1]  = 10+(0.15625*read_Adc());
        transmit_UART(outadc[countPot-1]);
        __delay_ms(500);
        }
        while(countPot>countServ){
        OC1R=outadc[countServ]*100;        
        countServ++;
        __delay_ms(500);
        
    }   */
}