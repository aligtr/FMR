// CONFIG3
#pragma config WPFP = WPFP511           // Write Protection Flash Page Segment Boundary (Highest Page (same as page 170))
#pragma config WPDIS = WPDIS            // Segment Write Protection Disable bit (Segmented code protection disabled)
#pragma config WPCFG = WPCFGDIS         // Configuration Word Code Page Protection Select bit (Last page(at the top of program memory) and Flash configuration words are not protected)
#pragma config WPEND = WPENDMEM         // Segment Write Protection End Page Select bit (Write Protect from WPFP to the last page of memory)

// CONFIG2
#pragma config POSCMOD = HS             // Primary Oscillator Select (HS oscillator mode selected)
#pragma config DISUVREG = ON           // Internal USB 3.3V Regulator Disable bit (Regulator is disabled)
#pragma config IOL1WAY = ON             // IOLOCK One-Way Set Enable bit (Write RP Registers Once)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSCO functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Both Clock Switching and Fail-safe Clock Monitor are disabled)
#pragma config FNOSC = PRI           // Oscillator Select (Fast RC oscillator with Postscaler (FRCDIV))
#pragma config PLL_96MHZ = ON           // 96MHz PLL Disable (Enabled)
#pragma config PLLDIV = DIV12           // USB 96 MHz PLL Prescaler Select bits (Oscillator input divided by 12 (48MHz input))
#pragma config IESO = OFF               // Internal External Switch Over Mode (IESO mode (Two-speed start-up)disabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = ON              // Watchdog Timer Enable (Watchdog Timer is enabled)
#pragma config ICS = PGx1               // Comm Channel Select (Emulator functions are shared with PGEC1/PGED1)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = ON              // JTAG Port Enable (JTAG port is enabled)


#define FOSC 32000000
#define FCY (FOSC/2)

#include <libpic30.h>
#include <xc.h>

#include <stdio.h>
#include <stdlib.h>

#define DUTY 20000

//#ifndef _XTAL_FREQ 
//#define _XTAL_FREQ 10000000 // ??????????? ???????? ???????  10 ???  ??? 
//#endif 

/*
 * 
 */
char word;
void init_PWM1()
{
    TMR1=0;//????????? ???????? ??????? ????????
    PR1 = 40000; // ?????? ?????????
    T1CONbits.TCKPS=0b01;//???????????? ?? 8
    T1CONbits.TON=1; // ????? ???????

    RPOR1bits.RP2R  = 18;   // pin as output RD8 
    OC1RS=40000; //?????? ?????????
    //OC1R=DUTY; //?????? ????????
    OC1CON2bits.SYNCSEL= 0b01011; //????????????? ? ????????1
    OC1CON2bits.OCTRIG=0b0;//????????? ????
    OC1CON1bits.OCTSEL=0b100;   
    OC1CON1bits.OCM=0b110;

}
void __attribute__((interrupt, auto_psv))_U1RXInterrupt(void)
{
U1STAbits.OERR = 0;
IFS0bits.U1RXIF = 0;
word=U1RXREG;
}

void __attribute__((interrupt, auto_psv))_U1TXInterrupt(void)
{
IFS0bits.U1TXIF = 0;
}

void init_UART()
{
    RPOR1bits.RP2R  = 18;
   RPOR7bits.RP15R  = 3;
   //RPINR18bits.U1RXR;
   
 U1MODEbits.BRGH=1;
 U1BRG=33.72;
 U1MODEbits.UARTEN=1;
IPC3bits.U1TXIP2 = 1; //Set Uart TX Interrupt Priority
IPC3bits.U1TXIP1 = 0;
IPC3bits.U1TXIP0 = 0;
IPC2bits.U1RXIP2 = 1; //Set Uart RX Interrupt Priority
IPC2bits.U1RXIP1 = 0;
IPC2bits.U1RXIP0 = 0;
U1STAbits.UTXEN = 1; //Enable Transmit
IFS0bits.U1TXIF = 0;
IEC0bits.U1TXIE = 1; //Enable Transmit Interrupt
IFS0bits.U1RXIF = 0;
IEC0bits.U1RXIE = 1; //Enable Receive Interruptreturn;
U1STAbits.URXISEL=0b11;
U1STAbits.UTXISEL1=1;
 }

void transmit_UART(char Tword)//???????? ????? (8???))
{
 //????????? ??????????   
    U1STAbits.UTXEN=1;
    U1TXREG=Tword;   
}

/*void receiv_UART()//????? ????? (8 ???)
{
   U1STAbits.URXISEL=11;
   

}*/
int main(void) {
    
//init_PWM1();


init_UART();
__delay_ms(5);
transmit_UART(0b11100010);
while (1){
    
OC1R=1000;//0.5-min - 0
__delay_ms(1000);
OC1R=2000;//1 - 45
__delay_ms(1000);
OC1R=3000;//1.5 - 90
__delay_ms(1000);
OC1R=4000;//2 - 135
__delay_ms(1000);
OC1R=5000;//2.5-max - 180
__delay_ms(1000);

}

return 0;
}
